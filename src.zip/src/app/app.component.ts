import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { CommonService } from './_services';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {

  constructor(
    private router: Router,
    private spinner: NgxSpinnerService,
    private commonService: CommonService,
  ) { 
    this.showHideSpinner();
  }

  /**
   * On page route page scroll top
   */
  onActive() {
    this.router.events.subscribe(() => {
      window.scrollTo({
        top: 1,
        left: 0,
        behavior: 'smooth'
      });
    });
  }

  /**
   * Show / Hide spinner
   */
  showHideSpinner() {
    this.commonService.isHideSpinner.subscribe((res: any) => {
      if (res && res?.is_hide_spinner) {
        this.spinner.hide();
      }
    });
  }
}
