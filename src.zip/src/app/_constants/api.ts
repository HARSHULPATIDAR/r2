export enum API {
    SAVE_USER = 'user/save',
    GET_USER = 'user/get',
    DELETE_USER = 'user/delete',
    LOGIN = 'user/login',

}

export enum GOOGLE_API {
    GET_LAT_LONG = 'geocode/json?key=AIzaSyApa4-zkv_t7-EzGOYDzT_koCXcnbj5pZs&address=',
    GET_DISTANCE = 'distancematrix/json?key=AIzaSyApa4-zkv_t7-EzGOYDzT_koCXcnbj5pZs&',
}
