import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DefaultLayoutComponent } from './_default-layout/default-layout.component';
import { LoginComponent } from './auth/login/login.component';
import { GuardService, PreventAccess } from './_guard';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'dashboard',
    pathMatch: 'full'
  },
  {
    path: '',
    component: DefaultLayoutComponent,
    children: [
      {
        path: '', canActivate: [GuardService],
        loadChildren: () => import('./views/views.module').then(m => m.ViewsModule)
      }
    ]
  },
  {
    path: '',
    redirectTo: 'auth/login',
    pathMatch: 'full'
  },
  { path: 'auth/login', component: LoginComponent, canActivate: [PreventAccess], }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
