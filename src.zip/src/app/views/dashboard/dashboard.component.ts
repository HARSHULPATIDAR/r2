import { Component, ElementRef, ViewChild, AfterViewInit } from '@angular/core';
import { CommonService } from '../../_services';
import { getLocalStorage } from '../../helpers';
import { LOCAL_KEY } from '../../_constants';
import * as QRCode from 'qrcode';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements AfterViewInit {
  userInfo: any = getLocalStorage(LOCAL_KEY.USER_DETAILS);
  selectedIndex = 0;
  phoneNumber = '+919974705577';
  @ViewChild('qrcode') qrcode!: ElementRef;

  constructor(private commonService: CommonService) {}

  ngAfterViewInit(): void {
    this.generateQRCode();
  }

  generateQRCode(): void {
    const link = `https://api.whatsapp.com/send?phone=${this.phoneNumber}&text=Hi`;

    QRCode.toCanvas(this.qrcode.nativeElement, link, (error) => {
      if (error) {
        console.error(error);
      }
    });
  }
}
