import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { FAICONS } from '../../_constants';

@Component({
  selector: 'app-confirmation-dialog',
  templateUrl: './confirmation-dialog.component.html',
  styleUrls: ['./confirmation-dialog.component.scss']
})
export class ConfirmationDialogComponent implements OnInit {
  constructor(
    public matDialogRef: MatDialogRef<ConfirmationDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) { }

  ngOnInit(): void {
    if (!this.data.icon) {
      this.data.icon = FAICONS.WARNING;
    }
    if (!this.data.cancelBtnLabel) {
      this.data.cancelBtnLabel = this.data.cancelBtnLabel;
    }
  }

  /**
   * On submit click to close modal
   */
  onSubmitClick() {
    this.matDialogRef.close('success');
  }
}
