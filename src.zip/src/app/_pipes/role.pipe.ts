import { Pipe, PipeTransform } from '@angular/core';
import { Roles } from '../_interfaces';

@Pipe({
    name: 'UserRole'
})
export class UserRolePipe implements PipeTransform {
    transform(value: any): any {
        return Roles.filter((item: any) => item.id === Number(value))[0]?.name;
    }
}