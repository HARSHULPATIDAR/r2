export const environment = {
  production: true,
  endpoint: 'https://scrapyard-api.aarchik.com/',
  projectURL: 'https://scrapyards.vercel.app/',
  googleAPI: 'https://maps.googleapis.com/maps/api/',
  encryptKey: '672473006935',
  encryptIV: '672476046983',
};
